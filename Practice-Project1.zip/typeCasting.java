package demo;

public class typeCasting {
	public static void main(String[] args) {
		//implicit type casting
	System.out.println("Implicit Type Casting");
	int a = 70;
	System.out.println("Value of a is: " +a);
	
	long b = a;
	System.out.println("Value of b is: " +b);
	
	float c = b;
	System.out.println("Value of c is: " +c);
	
	double d = c;
	System.out.println("Value of d is: " +d);
	
	char e = (char) d;
	System.out.println("Value of e is: " +e);
	
	System.out.println("\n");
	
	//Explicit TypeCasting
	System.out.println("Explicit Type Casting");
	double x=70.5;
	System.out.println("Value of x is: " +x);
	int y = (int)x;
	System.out.println("Value of y is: "+y);
	char z = (char)x;
	System.out.println("Value of z is: "+z);
	
	}
}
